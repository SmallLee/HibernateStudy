CREATE VIEW view_android AS
  SELECT
    `mysql`.`android`.`score` AS `score`,
    `mysql`.`android`.`level` AS `level`
  FROM `mysql`.`android`;
